# FocusHD

## What it does

A web extension that allows you to be focused on your daily work. 

## Features
* Blacklists
* Whitelists
* Regex lists
* Lives
* Help section